<?php $infoArray = array (
  'username' => 'mark',
  'password' => 'mark',
); ?>