<?php
session_start();

// Hardcoded access key - you might want to store this in a database or a safer place
$correct_access_key = 'SUHAIL_.315';

$message = "";
$messageColor = "red";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input_access_key = $_POST['access_key'];

    if ($input_access_key == $correct_access_key) {
        $_SESSION['access_granted'] = true;
        header('Location: usermanage.php'); // Redirect to user management page
        exit();
    } else {
        $message = "Access Denied!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
     <style>
        body {
    font-family: 'Arial', sans-serif;
    background-color: #282a36;
    color: white;
    margin: 0;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}

.container {
    width: 80%;
    max-width: 800px;
    margin-bottom: 20px;
    height: auto; /* Change to 'auto' for dynamic height */
    padding: 20px;
    margin-top: 20px;
    border-radius: 15px;
    background: rgba(40, 42, 54, 0.9);
    box-shadow: 0 0 10px rgba(0, 255, 255, 0.5);
    text-align: center;
}

form {
    display: flex;
    flex-direction: column;
}

input[type="text"], input[type="submit"] {
    margin-bottom: 20px;
    padding: 10px;
    width: 80%;
    margin: 0 auto;
    border-radius: 1px;
    border: 1px solid #0fa;
    background: transparent;
    color: #fff;
    font-size: 1.4em;
}

input[type="submit"] {
    cursor: pointer;
    background-color: #282a36; /* Button background */
    transition: background-color 0.3s, color 0.3s;
}

input[type="submit"]:hover {
    background-color: #0fa;
    color: #282a36;
}

h1, p {
    color: <?php echo $messageColor; ?>;
    font-size: 1.0em;
}
    </style>
</head>
<body>
    <div class="container">
        <h2>Enter Access Key</h2>
        <?php if ($message != ""): ?>
            <p style="color: <?php echo $messageColor; ?>;"><?php echo $message; ?></p>
        <?php endif; ?>
        <form method="post">
            <input type="text" name="access_key" placeholder="Access Key" required><br>
            <input type="submit" value="Submit">
        </form>
    </div>
</body>
</html>