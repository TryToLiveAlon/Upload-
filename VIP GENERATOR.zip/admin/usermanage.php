<?php
session_start();

// Yadi access key sahi nahi hai, to user ko access_key.php par redirect kar do
if (!isset($_SESSION['access_granted']) || $_SESSION['access_granted'] !== true) {
    header('Location: index.php');
    exit();
}

// Database Connection
$host = 'localhost';
$username = 'claimfre_vip';
$password = 'cheif@123';
$db_name = 'claimfre_vio';

$conn = new mysqli($host, $username, $password, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";
$messageColor = "green";

// Delete user logic
if (isset($_POST['delete_user'])) {
    $user_id = $_POST['user_id'];

    $delete_sql = "DELETE FROM users WHERE id = ?";
    $delete_stmt = $conn->prepare($delete_sql);

    if (!$delete_stmt) {
        $message = "Error in preparing delete statement: " . $conn->error;
    } else {
        $delete_stmt->bind_param("i", $user_id);

        if ($delete_stmt->execute()) {
            $message = "User Deleted Successfully.";
            $messageColor = "red";
        } else {
            $message = "Error deleting user: " . $delete_stmt->error;
        }

        $delete_stmt->close();
    }
}

// Update user logic
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_user'])) {
    $user_id = $_POST['user_id'];
    $is_vip = $_POST['isvip'] == 'vip' ? 1 : 0;

    $update_sql = "UPDATE users SET is_vip = ? WHERE id = ?";
    $update_stmt = $conn->prepare($update_sql);

    if (!$update_stmt) {
        $message = "Error in preparing update statement: " . $conn->error;
    } else {
        $update_stmt->bind_param("ii", $is_vip, $user_id);

        if ($update_stmt->execute()) {
            $message = "User Updated Successfully.";
            $messageColor = "yellow";
        } else {
            $message = "Error Updating User: " . $update_stmt->error;
        }

        $update_stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>User Management</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #282a36;
            color: white;
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            width: 80%;
            max-width: 800px;
            margin-bottom: 20px;
            height: auto; /* Change to 'auto' for dynamic height */
            padding: 20px;
            margin-top: 20px;
            border-radius: 15px;
            background: rgba(40, 42, 54, 0.9);
            box-shadow: 0 0 10px rgba(0, 255, 255, 0.5);
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
    margin-bottom: 8px;
    margin-top: 8px;
    padding: 0px;
    width: 50%; /* Adjusted width */
    border-radius: 0px;
    border: 0px solid #0fa;
    background: transparent;
    color: #fff;
    text-align: left;
    font-size: 1.0em;
}

select {
    margin-bottom: 20px;
    padding: 10px;
    width: 100%; /* Adjusted width */
    margin: 0 auto;
    border-radius: 5px;
    border: 1px solid #0fa;
    background: transparent;
    color: #fff;
    font-size: 1.4em;
}

input[type="submit"] {
    margin-bottom: 20px;
    padding: 10px;
    width: 90%; /* Adjusted width */
    margin: 0 auto;
    border-radius: 5px;
    border: 5px solid #0fa;
    background: transparent;
    color: #fff;
    font-size: 1.4em;
}

        input[type="submit"] {
            cursor: pointer;
            width: 50%; /* Adjusted width */
            text-align: center;
            margin: 0 auto;
            transition: background-color 0.3s, color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #0fa;
            color: #282a36;
        }

        .header-image {
            width: 40%;
            height: 40%;
            border-radius: 15px 15px 0 0;
        }

        h1, p {
            color: <?php echo $messageColor; ?>;
            font-size: 1.0em;
        }
    </style>
</head>
<body>
    <div class="container">
        <img src="../img/owner.png" alt="Header Image" class="header-image">
        <h2>User Management</h2>
        <?php if($message != ""): ?>
            <p style="color: <?php echo $messageColor; ?>;"><?php echo $message; ?></p>
        <?php endif; ?>

        <!-- Update User Form -->
        <form method="post">
            <label for="user_id">Select User:</label>
            <select name="user_id" id="user_id">
                <?php
                $sql = "SELECT id, username FROM users";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='".$row["id"]."'>".$row["username"]."</option>";
                    }
                } else {
                    echo "<option>No users found</option>";
                }
                ?>
            </select>
            <label for="isvip">User Type:</label>
            <select name="isvip" id="isvip">
                <option value="normal">FREE USER</option>
                <option value="vip">VIP USER</option>
            </select><br>

            <!-- Update User Button -->
            <input type="submit" name="update_user" value="Update User">
        </form>
<br><br>
        <!-- Delete User Form -->
        <form method="post">
            <label for="delete_user_id">User to Delete:</label>
            <select name="user_id" id="delete_user_id">
                <?php
                $result = $conn->query($sql); // Reusing the same query

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='".$row["id"]."'>".$row["username"]."</option>";
                    }
                } else {
                    echo "<option>No users found</option>";
                }
                ?>
            </select><br>

            <!-- Delete User Button -->
            <input type="submit" name="delete_user" value="Delete User" onclick="return confirm('Are you sure you want to delete this user?');">
        </form>
    </div>
</body>
</html>

<?php
$conn->close();
?>