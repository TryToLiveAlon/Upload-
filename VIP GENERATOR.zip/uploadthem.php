<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header("Location: signin.php");
    exit;
}

$userDetails = $_SESSION['loggedin'];
$isVip = isset($userDetails['is_vip']) && $userDetails['is_vip'] === 1;

$themesFile = 'themes.json';
$themesInfo = file_exists($themesFile) ? json_decode(file_get_contents($themesFile), true) : [];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['themeName'], $_FILES['themeFile'])) {
    $themeName = $_POST['themeName'];
    $isVipTheme = isset($_POST['isVip']) && $_POST['isVip'] === 'on'; // Check if the theme is for VIP
    $themeFile = $_FILES['themeFile'];

    // File upload logic
    if ($themeFile['error'] === 0) {
        $targetDirectory = "uploads/";
        if (!is_dir($targetDirectory) && !mkdir($targetDirectory, 0755, true)) {
            die("Error: Unable to create directory $targetDirectory");
        }
        $targetFile = $targetDirectory . basename($themeFile["name"]);
        $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        if ($fileType != "zip") {
            echo "Sorry, only ZIP files are allowed.";
        } else {
            if (move_uploaded_file($themeFile["tmp_name"], $targetFile)) {
                echo "The file " . htmlspecialchars(basename($themeFile["name"])) . " has been uploaded.";

                $themesInfo[$themeName] = ['isVip' => $isVipTheme];
                if (file_put_contents($themesFile, json_encode($themesInfo)) === false) {
                    echo "Error: Unable to write to file $themesFile";
                }
            } else {
                echo "Sorry, there was an error uploading your file.";
            }
        }
    } else {
        echo "Error: File upload error code " . $themeFile['error'];
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Theme</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        .container {
            width: 80%;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"], input[type="file"] {
            width: 100%;
            padding: 8px;
            border-radius: 4px;
            border: 1px solid #ddd;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Upload Theme</h1>
        <form method="post" enctype="multipart/form-data">
            <!-- Theme Upload Fields -->
            <label for="themeName">Theme Name:</label>
            <input type="text" name="themeName" required>

            <label for="themeFile">Theme File:</label>
            <input type="file" name="themeFile" required>

            <label for="isVip">VIP Only:</label>
            <input type="checkbox" name="isVip">

            <input type="submit" value="Upload Theme">
        </form>

        <h2>Select Theme</h2>
        <form method="post">
            <select name="theme" required>
                <?php foreach ($themesInfo as $themeName => $themeData): ?>
                    <?php
                    $disabledForNonVip = $themeData['isVip'] && !$isVip ? 'disabled' : '';
                    ?>
                    <option value="<?= htmlspecialchars($themeName) ?>" <?= $disabledForNonVip ?>>
                        <?= htmlspecialchars($themeName) ?> <?= $themeData['isVip'] ? '(VIP Only)' : '' ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <input type="submit" value="Select Theme">
        </form>
    </div>
</body>
</html>