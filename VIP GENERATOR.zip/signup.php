<?php
// Database Connection
$host = 'localhost';
$username = 'claimfre_vip';
$password = 'cheif@123';
$db_name = 'claimfre_vio';

$conn = new mysqli($host, $username, $password, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";
$messageType = "error"; // 'error' or 'success'

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $email = $_POST['email'];

    $sql = "INSERT INTO users (username, password, email) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        $message = "Error in preparing statement: " . $conn->error;
    } else {
        $stmt->bind_param("sss", $username, $password, $email);

        if ($stmt->execute()) {
            $message = "Signup successful! You can now <a href='signin.php'>Sign In</a>.";
            $messageType = "success";
        } else {
            $message = "Sign Up Failed: " . $stmt->error;
        }

        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <title>CHEIF GENERATOR SIGN UP</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #282a36;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            padding: 20px;
            border-radius: 15px;
            background: rgba(40, 42, 54, 0.9);
            box-shadow: 0 0 10px rgba(0, 255, 255, 0.5);
            animation: glowing 1.5s infinite;
            width: 300px;
        }
        @keyframes glowing {
            0% { box-shadow: 0 0 5px #0fa; }
            50% { box-shadow: 0 0 20px #0fa; }
            100% { box-shadow: 0 0 5px #0fa; }
        }
        h2 {
            color: #0fa;
            text-align: center;
            margin-bottom: 20px;
        }
        input[type="text"], input[type="password"], input[type="email"] {
            width: 95%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #0fa;
            background: transparent;
            color: #fff;
        }
        input[type="submit"] {
            width: 102%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #0fa;
            background: transparent;
            color: #0fa;
            cursor: pointer;
            transition: background-color 0.3s, color 0.3s;
        }
        input[type="submit"]:hover {
            background-color: #0fa;
            color: #000;
        }
        .error-message {
            color: #dc3545;
            text-align: center;
            font-weight: bold;
        }
        .links {
            text-align: center;
            margin-top: 20px;
        }
        .links a {
            color: #0fa;
            text-decoration: none;
        }
        .links a:hover {
            text-decoration: underline;
        }
        .footer {
            text-align: center;
            padding: 10px;
            background-color: #0fa;
            color: white;
            position: fixed;
            left: 0;
            bottom: 0;
            width: 100%;
        }
        .footer a {
            color: black;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
        .header {
            background-color: #282a36;
            text-align: center;
            padding: 10px 0;
        }
        .logo {
            width: 100px;
            height: auto;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <img src="img/gareeb.png" alt="Logo" class="logo">
        </div>
        <h2>Sign Up</h2>
        <form action="" method="post">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="submit" value="Sign Up">
        </form>
        <p class="error-message"><?php echo $message; ?></p>
        <div class="links">
            <p>Already have an account?</p><a href="signin.php">Sign In Here</a>
        </div>
    </div>
    <footer class="footer">
        <a href="https://telegram.me/PHISHING_BGMI_LINKS">CONTACT NOW</a>
    </footer>
</body>
</html>