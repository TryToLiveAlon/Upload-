<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: signin.php");
    exit;
}

// Database connection logic
$host = 'localhost';
$dbname = 'claimfre_vio';
$user = 'claimfre_vip';
$pass = 'cheif@123';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
} catch (PDOException $e) {
    die("Could not connect to the database $dbname :" . $e->getMessage());
}

$username = $_SESSION['username'];

$sql = "SELECT * FROM users WHERE username = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$username]);
$userDetails = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if login success flag is set
if (isset($_SESSION['show_login_success']) && $_SESSION['show_login_success']) {
    echo '<script>alert("Login successful!");</script>';
    $_SESSION['show_login_success'] = false;
}

// Determine logo based on VIP status
$isVip = isset($userDetails['is_vip']) && (int)$userDetails['is_vip'] === 1;
$logoPath = $isVip ? 'img/vip.png' : 'img/gareeb.png';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Details</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #282a36;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            padding: 20px;
            border-radius: 15px;
            background: rgba(40, 42, 54, 0.9);
            box-shadow: 0 0 10px rgba(0, 255, 255, 0.5);
            animation: glowing 1.5s infinite;
            width: 300px;
        }

        @keyframes glowing {
            0% { box-shadow: 0 0 5px #0fa; }
            50% { box-shadow: 0 0 20px #0fa; }
            100% { box-shadow: 0 0 5px #0fa; }
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
            padding: 20px;
            background-color: #000;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.6);
            color: #fff;
        }

        .header img {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            border: 4px solid white;
            box-shadow: 0 0 15px rgba(255, 255, 255, 0.4);
            margin-bottom: 20px;
        }

        .header h1 {
            margin: 10px 0;
            font-size: 2.2em;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
            letter-spacing: 1.5px;
        }

        .nav-menu {
            background-color: #0fa;
            overflow: hidden;
            display: flex;
            justify-content: space-around;
            margin-top: 16px;
            margin-bottom: 16px;
        }

        .nav-menu a {
            color: white;
            text-decoration: none;
            padding: 14px 16px;
        }

        .nav-menu a:hover {
            background-color: #ddd;
            color: black;
        }

        .container2 {
            padding: 20px;
            border-radius: 15px;
            background: rgba(40, 42, 54, 0.9);
            box-shadow: 0 0 10px rgba(0, 255, 255, 0.5);
            animation: glowing 1.5s infinite;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        ul li {
            padding: 8px;
            background: #45a049;
            margin-bottom: 5px;
            border-radius: 4px;
        }

        .button {
            padding: 10px 15px;
            border-radius: 5px;
            border: 1px solid #0fa;
            background: transparent;
            color: #0fa;
            cursor: pointer;
            transition: background-color 0.3s, color 0.3s;
        }

        .button:hover {
            background-color: #0fa;
            color: #fff;
        }

        .button-container {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 20px;
        }

        .footer {
            text-align: center;
            padding: 10px;
            background-color: #0fa;
            color: white;
            position: fixed;
            left: 0;
            bottom: 0;
            width: 100%;
            box-sizing: border-box;
        }

        .footer a {
            color: black;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="nav-menu">
        <a href="generate.php" class="button">Create Web</a>
        <a href="logout.php" class="button">Logout</a>
    </div>
    <div class="header">
            <img src="<?php echo htmlspecialchars($logoPath); ?>" alt="User Logo">
        <h3>Welcome, <?php echo htmlspecialchars($userDetails['username']); ?>!</h3>
    </div>
    <div class="container2">
        <h2>User Details</h2>
        <ul>
            <li><strong>Username:</strong> <?php echo htmlspecialchars($userDetails['username']); ?></li>
            <li><strong>Email:</strong> <?php echo htmlspecialchars($userDetails['email']); ?></li>
            <!-- Add more user details here -->
        </ul>
        <div class="button-container">
            <a href="generate.php" class="button">Generate Web</a
            </div>
            <footer class="footer">
        <a href="https://telegram.me/CHEIF_YT">CONTACT NOW</a>
    </footer>
</body>
</html>