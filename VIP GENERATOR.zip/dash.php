<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: signup.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CHEIF WEB GENERATOR</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .header {
            background: url('img/logo.png') no-repeat center center/cover;
            height: 300px;
            color: white;
        }
        .nav-menu {
            background-color: #333;
            overflow: hidden;
        }
        .nav-menu a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }
        .nav-menu a:hover {
            background-color: #ddd;
            color: black;
        }
        .container {
            padding: 20px;
        }
        .vip-section {
            background-color: gold;
            padding: 10px;
            margin-top: 20px;
            border-radius: 5px;
        }
                .footer {
    text-align: center;
    padding: 20px;
    background-color: #f1f1f1;
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    box-shadow: 0 -2px 4px rgba(0, 0, 0, 0.1);
}

.footer p {
    margin: 0;
    color: #333;
}

.footer a {
    color: #007bff;
    text-decoration: none;
}

.footer a:hover {
    text-decoration: underline;
}
    </style>
</head>
<body>

<div class="header">
    <h1>Welcome to Our Theme Management System</h1>
</div>

<div class="nav-menu">
    <a href="logout.php">Log Out</a>
    <a href="generate.php">Make Web</a>
    <a href="#vip">VIP Section</a>
</div>

<div class="container">
    <h2>Welcome to the Main Page</h2>
    <p>Select an option from the menu to get started.</p>

    <div class="vip-section" id="vip">
        <h3>VIP Section</h3>
        <p>Exclusive content for VIP members.</p>
        <!-- Add more VIP content here -->
    </div>
    <footer class="footer">
    <p>Contact Web Developer: <a href="https://telegram.me/CHEIF_YT">CONTACT NOW</a></p>
</footer>
</div>
</div>

</body>
</html>